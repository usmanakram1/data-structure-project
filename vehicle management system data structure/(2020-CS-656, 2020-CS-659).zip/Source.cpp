#include<iostream>
#include<conio.h>
#include<string>
#include <iomanip>	// manipulator function

using namespace std;

class Driver
{
public:
	string D_name;
	string D_id;
	int age;
	string ph_no;
	bool li_holder;
	Driver(string na = " ", string id = " ", int a = 0, string ph = " ", bool lic = false)
	{

	}

	void DisplayDriverInfo()
	{
		cout << right << "| " << D_name;

		cout << setw(12) << "| " << D_id;

		cout << setw(19) << "| " << age;

		cout << setw(20) << "| " << ph_no;

		cout << setw(10) << "| "; 

		if (li_holder == true)
		{
			cout << " YES " << endl;
		}
		else
		{
			cout << "NO " << endl;

		}


	}
};

class ListNode
{
public:
	Driver data;
	ListNode* next;
	ListNode(Driver d)
	{
		data = d;
	}

};



class singly
{
	ListNode* head;


public:
	singly()
	{
		head = NULL;
	}
	ListNode* getHead()
	{
		return head;
	}
	void InsertAtStart(Driver d);
	void DeleteAtStart();
	void display();
};


void singly::InsertAtStart(Driver d)
{
	ListNode* newnode = new ListNode(d);

	if (head == NULL)
	{
		head = newnode;
		return;
	}
	else if (head != NULL)
	{
		newnode->next = head;
		head = newnode;
		return;
	}
}


void singly::DeleteAtStart()
{
	ListNode* temp1 = head;

	if (temp1 != NULL)
	{

		head = head->next;
		delete temp1;
		cout << "\n\n\t\t\t OPERATION PERFORMED SUCCESSFULLY!!!\n";

		return;
	}
	else
	{
		cout << "\n\n\t\tDriver list is empty\n\n";
		return;
	}

}

void singly::display()
{
	ListNode* temp = head;
	if (head == NULL)
	{
		cout << "List is Empty..." << endl;
		return;
	}
	while (temp != NULL)
	{
		temp->data.DisplayDriverInfo();
		temp = temp->next;
	}
}

class Customer
{
public:
	string name;
	string contact;
	int carNum;
	Customer(string na = " ", string cont = " ", int cnum = 0)
	{

	}

	void DisplayCustomerInfo()
	{
		cout << right << "| " << name;

		cout << setw(12) << "| " << contact;

		cout << setw(19) << "| " << carNum;

		cout << setw(10) << "| ";
		cout << endl;
	}

};

class CNode
{

 public:
	 Customer data;
	 CNode* next;
	 CNode(Customer c)
	 {
		 data = c;
		 next = NULL;
	 }

};

class CQueue
{
	CNode* head;
public:
	CQueue()
	{
		head = NULL;
	}
	void insertAtEnd(Customer c);
	void DeleteAtStart();
	
	void display();
};

void CQueue::insertAtEnd(Customer c)
{
	
		CNode* newnode = new CNode(c);
		

		CNode* temp = head;

		if (temp == NULL)
		{
			head = newnode;
			return ;
		}
		else
		{

			while (temp->next != NULL) {
				temp = temp->next;
			}
			if (temp->next == NULL) {
				temp->next = newnode;
				return ;
			}
			else 
			{
				return ;
			}
		}
	
}
void CQueue::DeleteAtStart()
{

	CNode* temp1 = head;

	if (temp1 != NULL)
	{


		head = head->next;
		cout << "\n\t\tcustomer data is deleted successfully !!\n";
		delete temp1;
		return ;
	}
	else
	{
		cout << "\n List is empty\n";
		return ;
	}

}
void CQueue::display()
{
	
		CNode* temp = head;
		if (head == NULL)
		{
			cout << "List is Empty..." << endl;
			return;
		}
		while (temp != NULL)
		{
			temp->data.DisplayCustomerInfo();
			temp = temp->next;
		}
	

}


class Driver_List
{
public:
	singly D_List;
	Driver_List()
	{
	}
	void Push(Driver d);
	Driver Pop();
	Driver Top();
};

void Driver_List::Push(Driver d)
{
	D_List.InsertAtStart(d);
}

Driver Driver_List::Pop()
{
	Driver Dr;
	if (D_List.getHead()==NULL)
	{
		cout << "\n\n\t\tDriver list is already empty!!!\n\n";
		return Dr;
	}
	Dr = D_List.getHead()->data;
	D_List.DeleteAtStart();
	return Dr;
}

Driver Driver_List::Top()
{
	Driver Dr;
	if (D_List.getHead() == NULL)
	{

		return Dr;
	}
	Dr = D_List.getHead()->data;
	return Dr;
}

class Car
{
public:

	int car_no;
	string car_name;
	string engine_no;
	int engine_cc;
	long int car_price;
	Car(int cn = 0, string name = " ", string en = " ", int ecc = 0,long int pric=0)
	{
		car_no = cn;
		car_name = name;
		engine_no = en;
		engine_cc = ecc;
		car_price = pric;
	}
	void DisplayCarInfo()
	{
		
		cout << right << "| " << car_no;

		cout << setw(19) << "| "<<car_name;

		cout << setw(19) << "| "<<engine_no;

		cout << setw(20) << "| "<<engine_cc; 

		cout << setw(10) << "| "<<car_price<<endl<<endl;




	}
};

class Node
{
public:
	Car data;
	Node* left = NULL;
	Node* right = NULL;
	Node(Car temp)
	{
		data = temp;
		left = NULL;
		right = NULL;
	}

};

class manage_cars
{
	Node* root;
public:
	manage_cars()
	{
		root = NULL;
	}

	Node* get_root()
	{
		return root;
	}


	void insertion(Car);
	void search(int);
	void dispaly_preorder(Node*);
    void deletetion(int val);
	bool car_exist(int);
};

void manage_cars::deletetion(int val)
{
	Node* temp = root;

	if (root == NULL)
	{
		cout << "\n\n\t\tList is already empty " << endl << endl;
	}
	else
	{
		Node* parent = root;
		while (temp != NULL)
		{
			if (val == temp->data.car_no)
			{
				break;
			}
			else if (val < temp->data.car_no)
			{
				parent = temp;
				temp = temp->left;
			}
			else
			{
				parent = temp;

				temp = temp->right;
			}

			if (temp == NULL)
			{
				cout << "\n\n\t\tYOUR CHOICE IS INCORRECT!!! \n" << endl;
				return;
			}
		}


		if (temp->left == NULL && temp->right == NULL)      //for leaf
		{
			if (temp == root)
			{
				root = NULL;
			}
			else if (parent->left == temp)
			{
				parent->left = NULL;
			}

			else
			{
				parent->right = NULL;
			}

			delete temp;

			cout << "\n\n\t\t\tTHANKS FOR SELECTING THIS CAR\n\n";

		}

		else if (temp->left == NULL || temp->right == NULL)          //for single child
		{
			if (temp->left == NULL)
			{
				if (temp == root)
				{
					root = temp->right;
				}

				else if (parent->left == temp)
				{
					parent->left = temp->right;
				}
				else
				{
					parent->right = temp->right;
				}
				delete temp;
			}

			else
			{
				if (temp == root)
				{
					root = temp->left;
				}

				else if (parent->left == temp)
				{
					parent->left = temp->left;
				}
				else
				{
					parent->right = temp->left;
				}
				delete temp;
			}
			cout << "\n\n\t\t\tTHANKS FOR SELECTING THIS CAR\n\n";

		}

		else       // for two childs
		{

			Node* temp2 = temp->right;
			Node* p = NULL;


			while (temp2->left != NULL)   //inorder successor
			{
				p = temp2;
				temp2 = temp2->left;
			}

			temp->data = temp2->data;

			if (temp2->left == NULL && temp2->right == NULL)      //for leaf
			{

				if (p->left == temp2)
				{
					p->left = NULL;
				}

				else
				{
					p->right = NULL;
				}

				delete temp2;

				cout << "\n\n\t\t\tTHANKS FOR SELECTING THIS CAR\n\n";

			}

			else if (temp2->left == NULL || temp2->right == NULL)          //for single child
			{
				if (temp2->left == NULL)
				{

					if (p->left == temp2)
					{
						p->left = temp2->right;
					}
					else
					{
						p->right = temp2->right;
					}
					delete temp2;
				}

				
				cout << "\n\n\t\t\tTHANKS FOR SELECTING THIS CAR\n\n";

			}
		}



	}

}

void manage_cars::insertion(Car c)
{
	Node* newnode = new Node(c);
	int value = c.car_no;

	if (root == NULL)
	{
		root = newnode;
		return;
	}

	else
	{
		Node* temp = root;
		while (temp != NULL)
		{
			if (value > temp->data.car_no)
			{
				if (temp->right == NULL)
				{
					temp->right = newnode;
					return;
				}
				temp = temp->right;

			}

			else
			{
				if (temp->left == NULL)
				{
					temp->left = newnode;
					return;
				}
				temp = temp->left;
			}
		}


	}
}


void manage_cars::search(int val)
{
	Node* temp = root;
	if (root == NULL)
	{
		cout << "\n\n\t\tList is empty " << endl << endl;
		return;
	}
	else
	{
		while (temp != NULL)
		{
			if (val == temp->data.car_no)
			{
				
				temp->data.DisplayCarInfo();

				return;
			}
			else if (val < temp->data.car_no)
			{

				temp = temp->left;
			}
			else
			{
				temp = temp->right;
			}

			if (temp == NULL)
			{
				cout << "\n\n\t\t\tVALUE NOT FFOUND!!! \n" << endl;
				return;
			}
		}
	}

}


bool manage_cars::car_exist(int val)
{
	Node* temp = root;
	if (root == NULL)
	{
		return false;
	}
	else
	{
		while (temp != NULL)
		{
			if (val == temp->data.car_no)
			{
             return true;
			}
			else if (val < temp->data.car_no)
			{

				temp = temp->left;
			}
			else
			{
				temp = temp->right;
			}

			if (temp == NULL)
			{
				return false;
			}
		}
	}

}



void manage_cars::dispaly_preorder(Node* temp)    // PLR
{
	if (root == NULL)
	{
		cout << "\n\n\t\tLIST IS EMPTY!!! " << endl << endl;
	}
	else
	{
		if (temp == NULL)
		{
			return;
		}
		temp->data.DisplayCarInfo();
		dispaly_preorder(temp->left);
		dispaly_preorder(temp->right);

	}
}



class Admin
{
public:
	//int total_sales;
	manage_cars cars;
	Driver_List drivers;
	CQueue custo;
	Admin()
	{
	}
	void add_car(Car c)
	{
		cars.insertion(c);
	}
	void  view_cars()
	{
		cout << endl << endl;
		cout << left << setw(20) << "Car # " << "|" << setw(20) << "Name" << "|"
			<< setw(20) << "Engine #" << "|" << setw(15) << "  CC " << "|" << setw(20) << "Price" << endl;

		cars.dispaly_preorder(cars.get_root());
	}

	void search_car(int n)
	{
		cars.search(n);
	}

	void add_driver(Driver d)
	{
		drivers.Push(d);
	}
	void remove_driver()
	{
		drivers.Pop();
	}
	void view_driver_list()
	{
		cout << endl << endl;
		cout << left << setw(20) << "|Name " << "|" << setw(20) << "ID #" << "|"
			<< setw(20) << "Age" << "|" << setw(15) << "Phone # " << "|" << setw(20) << "License Holder" << endl;

		drivers.D_List.display();
	}

	void sale_car(Car c)
	{
		cars.insertion(c);
	}
	void rent_car(int a)
	{
		cars.deletetion(a);
	}
	void lease_car(int a)
	{
		cars.deletetion(a);
	}
	void buy_car(int a)
	{
		cars.deletetion(a);
	}

	void summary_report()
	{
		cout << endl << endl;
		cout << left << setw(20) << "|Name " << "|" << setw(20) << "Phone #" << "|"
			<< setw(20) << "Car #" << "|"  << endl;

		custo.display();
	}
	void customer_delete()
	{
		custo.DeleteAtStart();
	}
};


void menu()
{

	
	Driver d;
	Car c1;
	Admin a;
	Customer c2;
L1:
	system("cls");


	cout << "\n\n" <<  "\t\t\t\t==========================================================";
	cout << "\n\n" <<"\t\t\t\t     =================================================";
	cout << "\n\n" <<  "\t\t\t\t\t	~ CARS MANAGEMENT SYSTEM ~";
	cout << "\n\n" << "\t\t\t\t     =================================================";
	cout << "\n\n" << "\t\t\t\t==========================================================";


	cout << "\n\n\n\n";
	int ch;
	cout <<  "\t\t\t\t\t1.MANAGE CARS\n";
	cout <<  "\t\t\t\t\t2.MANAGE DRIVERS\n";
	cout <<  "\t\t\t\t\t3.DEALING CARS\n";
	cout <<  "\t\t\t\t\t4.CUSTOMERS SUMMARY REPORT\n";
	cout << "\t\t\t\t\t5.EXIT.\n";
	cout << "\t\t\t\t\t6.customer delete.\n";


	cout << "\n\tPlease enter a number : ";
	cin >> ch;

	switch (ch)
	{

	case 1:
	{
	L2:
		system("cls");

		cout << "\n\n" <<  "\t\t\t\t\t\t\t============================="; 
		cout << "\n\n" << "\t\t\t\t\t\t\t======== MANAGE CARS ========"; 
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";

		int ch1;
		cout << "\n\t\t\t\t\t0.DEFAULT CARS\n";
        cout << "\t\t\t\t\t1.VIEW CARS\n";
		cout << "\t\t\t\t\t2.ADD CARS\n";
		cout << "\t\t\t\t\t3.SEARCH CARS\n";
		cout << "\t\t\t\t\t4.BACK TO MENU\n";
		cout << "\t\t\t\t\t5.EXIT\n";

		cout << "\n\tPlease enter a number : ";
		cin >> ch1;

		switch (ch1)
		{
		case 0:
			c1.car_no = 1;
			c1.engine_no = 56;
			c1.engine_cc = 1600;
			c1.car_name = "suzuki";
			c1.car_price = 360000;
			a.cars.insertion(c1);

			c1.car_no = 2;
			c1.engine_no = 56;
			c1.engine_cc = 1800;
			c1.car_name = "civic";
			c1.car_price = 360000;
			a.cars.insertion(c1);
			break;
		case 1:
			a.view_cars();
			break;
		case 2:

			cout << "\nEnter car no  :";
			cin >> c1.car_no;
			while (a.cars.car_exist(c1.car_no))
			{
				cout << "\n\n\t\tThis car number is already exist!!!\n";
				cout << "\nPlease enter again car no  :";
				cin >> c1.car_no;
			}
			cout << "\nEnter engine no : ";
			cin >> c1.engine_no;
			
			cout << "\nEnter engine cc : ";
			cin >> c1.engine_cc;

			
			c1.engine_cc = abs(c1.engine_cc);
			cin.ignore();
			cout << "\nEnter car name : ";
			getline(cin, c1.car_name);

			for (int i = 0; i <= c1.car_name.length(); i++)
			{

				if (c1.car_name[i] == 0 || c1.car_name[i] == 1 || c1.car_name[i] == 2 || c1.car_name[i] == 3 || c1.car_name[i] == 4 || c1.car_name[i] == 5 || c1.car_name[i] == 6 || c1.car_name[i] == 7 || c1.car_name[i] == 8 || c1.car_name[i] == 9)
				{
					cout << "\n\tPlease enter characters!!!\n";

					cout << "\nEnter car name : ";
					getline(cin, c1.car_name);

					break;
				}
			}
			cout << "\nEnter car price  :";
			cin >> c1.car_price;
			c1.car_price = abs(c1.car_price);
			a.add_car(c1);
			
			break;
		case 3:
			int num;
			cout << "\nEnter car no  :";
			cin >> num;
			a.search_car(num);
			break;
		case 4:
			goto L1;
			break;
		case 5:
			exit(0);
		default:
			cout << "\n\n\t\tYou entered an invalid number!!!\n\n";
		}

		system("pause");

		goto L2;
		break;
	}
	case 2:
	{
	L3:
		system("cls");

		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << "\n\n" << "\t\t\t\t\t\t\t======== MANAGE DRIVERS =====";
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";

		int ch2;
		cout << "\n\t\t\t\t\t0.Deault DRIVER\n";
       cout << "\t\t\t\t\t1.ADD DRIVER\n";
		cout << "\t\t\t\t\t2.REMOVE DRIVER\n";
		cout << "\t\t\t\t\t3.VIEW DRIVER LIST\n";
		cout << "\t\t\t\t\t4.BACK TO MENU\n";
		cout << "\t\t\t\t\t5.EXIT\n";

		cout << "\n\tPlease enter a number : ";
		cin >> ch2;

		switch (ch2)
		{

		case 0:
			d.D_name = "junaid";
			d.D_id = "23444";
			d.ph_no = 0232353;
			d.age = 21;
			d.li_holder = true;
			a.add_driver(d);

			d.D_name = "zaryab";
			d.D_id = "234565";
			d.ph_no = 02353453;
			d.age = 18;
			d.li_holder = false;
			a.add_driver(d);
			break;

		case 1:
			char c;
			cin.ignore();
			cout << "\nEnter you name :";
			getline(cin, d.D_name);
			/*for (int i = 0; i <= d.D_name.length(); i++)
			{

				if (d.D_name[i] == 0 || d.D_name[i] == 1 || d.D_name[i] == 2 || d.D_name[i] == 3 || d.D_name[i] == 4 || d.D_name[i] == 5 || d.D_name[i] == 6 || d.D_name[i] == 7 ||  d.D_name[i] == 8 || d.D_name[i] == 9 )
				{
					cout << "\n\tPlease enter characters!!!\n";

					cout << "\nEnter you name :";
					getline(cin, d.D_name);
					break;
				}
			}*/
				
			cout << "\nEnter you ID number :";
			getline(cin, d.D_id);
			while (d.D_id.length() != 13)
			{
				cout << "\n\tPlease enter 13 digits!!!\n";

				cout << "\nPlease enter you ID number :";
				getline(cin, d.D_id);
			}
			cout << "\nEnter you contact mumber :";
			getline(cin, d.ph_no);

			cout << "\nEnter you age :";
			cin >> d.age;
			while (d.age < 18)
			{
				cout << "\n\tPlease enter 18+ age!!!\n";
				cout << "\nPlease enter again your age :";
				cin >> d.age;
			}
			d.age = abs(d.age);
			cout << "\nAre you license holder? (Y/N) :";
			cin >> c;
			while ((c != 'Y') && (c != 'y') && (c != 'n') && (c != 'N'))
			{
				cout << "Invalid" << endl;
				cout << "\nAre you license holder? (Y/N) :";
				cin >> c;
			}
			if (c == 'Y' || c == 'y')
			{
				d.li_holder = true;
			}
			else
			{
			    d.li_holder = false;
			}
			a.add_driver(d);
			break;
		case 2:
			a.remove_driver();
			break;
		case 3:
			a.view_driver_list();
			break;
		case 4:
			goto L1;
			break;
		case 5:
			exit(0);
		default:
			cout << "\n\t\tYou entered an invalid number!!!\n\n";
		}

		system("pause");

		goto L3;
		break;

	}

	case 3:
	{
	L4:
		system("cls");

		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << "\n\n" << "\t\t\t\t\t\t\t======== DEALING CARS =======";
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		int ch3;
		cout << "\n\t\t\t\t\t1.SALE CARS\n";
		cout << "\t\t\t\t\t2.RENT CAR\n";
		cout << "\t\t\t\t\t3.LEASE CAR\n";
		cout << "\t\t\t\t\t4.BUY CAR\n";
		cout << "\t\t\t\t\t5.BACK TO MENU\n";
		cout << "\t\t\t\t\t6.EXIT\n";

		cout << "\n\tPlease enter a number : ";
		cin >> ch3;

		switch (ch3)
		{
	
		case 1:
			cout << "\nEnter car no  :";
			cin >> c1.car_no;
			while (a.cars.car_exist(c1.car_no))
			{
				cout << "\n\t\tThis car number is already exist!!!\n";
				cout << "\nPlease enter again car no  :";
				cin >> c1.car_no;
			}
			cout << "\nEnter engine no : ";
			cin >> c1.engine_no;
			cout << "\nEnter engine cc : ";
			cin >> c1.engine_cc;
			cin.ignore();
			cout << "\nEnter car name : ";
			getline(cin, c1.car_name);
			cout << "\nEnter car price  :";
			cin >> c1.car_price;
			cin.ignore();

			//customer data
			cout << "\nEnter your name : ";
			getline(cin, c2.name);
			cout << "\nEnter your contact : ";
			getline(cin, c2.contact);
			c2.carNum = c1.car_no;
			a.custo.insertAtEnd(c2);
			a.sale_car(c1);
			

			break;
		case 2:
			a.view_cars();

			if (a.cars.get_root() != NULL)
			{
				//customer data
				cin.ignore();
				cout << "\nEnter your name : ";
				getline(cin, c2.name);
				cout << "\nEnter your contact : ";
				getline(cin, c2.contact);
				
			char ch;
			bool dr;
			cout << "\nDo you need a driver (Y/N): ";
			cin >> ch;
			while ((ch != 'Y') && (ch != 'y') && (ch != 'n') && (ch != 'N'))
			{
				cout << "Invalid" << endl;
				cout << "\nDo you need a driver (Y/N) :";
				cin >> ch;
			}
			if (ch == 'Y' || ch == 'y')
			{
				dr = true;
			}
			else
			{
				dr = false;
			}
			if (dr == true)
			{
				a.remove_driver();
			}

			cout << "'\n\t\t\t\t OUR PER DAY CHARGES OF RENT ARE 3000 ruppies";
			cout << "'\n\t\t\t\t OUR PER DAY CHARGES OF DRIVER ARE 2000 ruppies\n";
			int pricea, days;
			cout << endl;
			cout << "\n\t FOR HOW MANY DAYS YOU WANT TO RENT A CAR. : ";
			cin >> days;
		g1:
			cout << "\n\tEnter a car no which do you want : ";
			cin >> c1.car_no;
			if (a.cars.car_exist(c1.car_no))
			{

				a.rent_car(c1.car_no);

			}
			else
			{
				cout << "\n\t\tYou entered an invalid number!!!\n\n";
				goto g1;
			}
			c2.carNum = c1.car_no;
			a.custo.insertAtEnd(c2);
			if (dr == true)
			{
				pricea = (days * 3000) + (days*2000);


			}
			else
				pricea = days * 3000;
			cout << "\n\t\t YOUR RENT CHARGES FOR  " << days << "  DAYS ARE :" << pricea << endl;
		}
				
			break;
		case 3:
			a.view_cars();
			
			
			if (a.cars.get_root() != NULL)
			{
				//customer data
				cin.ignore();
				cout << "\nEnter your name : ";
				getline(cin, c2.name);
				cout << "\nEnter your contact : ";
				getline(cin, c2.contact);
				
			g2:
				cout << "\nEnter a car no which do you want : ";
				cin >> c1.car_no;
				if (a.cars.car_exist(c1.car_no))
				{

					a.lease_car(c1.car_no);

				}
				else
				{
					cout << "\n\t\tYou entered an invalid number!!!";
					goto g2;
				}
				c2.carNum = c1.car_no;
				a.custo.insertAtEnd(c2);
				cout << "\n\t WE CHARGE 5% EXTRA TAX FOR 1 YEAR & 10% EXTRA FOR 2 YEAES & 15% EXTRA ";
				int year;
				long int priceb;
				cout << "\n\t\t FOR HOW MANY YEARS YOU WANT INSTALLMENT : ";
				cin >> year;
				while (year != 1 && year != 2&&year!=3 )
				{
					cout << "\n\t\tYOU ENTERED AN INVALID YEAR!!!\n";
					cout << "\n\t\t PLEASE ENTER AGAIN FOR HOW MANY YEARS YOU WANT INSTALLMENT : ";
					cin >> year;
				}
				cout << "ORIGNAL PRICE OF YOUR SELECTED CAR IS : " << c1.car_price << endl;
				int y = 0;
				if (year == 1)
				{
					priceb = (c1.car_price * 5);
					priceb = priceb / 100;
					priceb = c1.car_price + priceb;
					y = 12;

				}
				else if (year == 2)
				{
					priceb = (c1.car_price * 10);
					priceb = priceb / 100;
					priceb = c1.car_price + priceb;
					y = 24;
				}
				else if (year == 3)
				{
					priceb = (c1.car_price * 15);
					priceb = priceb / 100;
					priceb = c1.car_price + priceb;
					y = 36;
				}
				cout << " \n\t\tYOUR TOTAL PAYMENT IS :" << priceb;
				cout << endl;
				cout << " \n\tYOUR PER MONTH INSTALLMENT IS :" << priceb /y << endl;
			}
			break;
		case 4:
		
			a.view_cars();
		
			if (a.cars.get_root() != NULL)
			{
				//customer data
				cin.ignore();
				cout << "\nEnter your name : ";
				getline(cin, c2.name);
				cout << "\nEnter your contact : ";
				getline(cin, c2.contact);
				
			g3:
				cout << "\n\tEnter a car no which do you want : ";
				cin >> c1.car_no;
				if (a.cars.car_exist(c1.car_no))
				{

					a.buy_car(c1.car_no);

				}
				else
				{
					cout << "\n\t\tYou entered an invalid number!!!\n\n";
					goto g3;
				}
				c2.carNum = c1.car_no;
				a.custo.insertAtEnd(c2);
				cout << " \n\t\tYOUR TOTAL PAYMENT IS :" << c1.car_price << endl;
				cout << endl;
			}
			break;
		case 5:
			goto L1;
			break;
		case 6:
			exit(0);
		default:
			cout << "\n\t\tYou entered an invalid number!!!\n\n";
		

		}

		system("pause");

		goto L4;
		break;
	}

	case 4:


		system("cls");
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << "\n\n" << "\t\t\t\t\t\t\t======== SUMMARY REPORT =====";
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << endl;
		a.summary_report();
		
		break;
	case 5:
		exit(0);
		break;
	default:
		cout << "\n\n\t\t\tYou entered an invalid number!!!!\n\n\n";
	case 6:


		system("cls");
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << "\n\n" << "\t\t\t\t\t\t\t======== delete customer =====";
		cout << "\n\n" << "\t\t\t\t\t\t\t=============================";
		cout << endl;
		a.customer_delete();
		cout << endl;

		break;


	}
	system("pause");

	goto L1;

}




int main()
{

	menu();



}